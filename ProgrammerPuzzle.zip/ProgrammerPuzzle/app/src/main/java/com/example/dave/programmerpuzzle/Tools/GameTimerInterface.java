package com.example.dave.programmerpuzzle.Tools;

public interface GameTimerInterface {
    void tick(long timeLeft);
    void end();
}
